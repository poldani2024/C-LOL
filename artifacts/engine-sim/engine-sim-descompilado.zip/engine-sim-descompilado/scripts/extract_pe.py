import hashlib, json, pathlib, re
import pefile

src=pathlib.Path('/workspace/attachments/eb9e57dd-02e7-497b-87fc-76fe9fc098ba/engine-sim-app.exe')
out=pathlib.Path('/workspace/engine-sim-analysis/output')
out.mkdir(exist_ok=True)
pe=pefile.PE(str(src))
meta={
    'file':src.name, 'size':src.stat().st_size, 'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
    'machine':hex(pe.FILE_HEADER.Machine), 'linker_version':f'{pe.OPTIONAL_HEADER.MajorLinkerVersion}.{pe.OPTIONAL_HEADER.MinorLinkerVersion}',
    'timestamp_unverified':pe.FILE_HEADER.TimeDateStamp, 'image_base':hex(pe.OPTIONAL_HEADER.ImageBase),
    'entry_point':hex(pe.OPTIONAL_HEADER.ImageBase+pe.OPTIONAL_HEADER.AddressOfEntryPoint),
    'clr_header_present':bool(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress),
    'sections':[{'name':s.Name.rstrip(b'\0').decode(errors='replace'),'rva':hex(s.VirtualAddress),'raw_size':s.SizeOfRawData,'entropy':s.get_entropy()} for s in pe.sections],
}
imports=[]
for dll in getattr(pe,'DIRECTORY_ENTRY_IMPORT',[]):
    for imp in dll.imports:
        imports.append({'dll':dll.dll.decode(errors='replace'),'name':imp.name.decode(errors='replace') if imp.name else None,'ordinal':imp.ordinal,'address':hex(imp.address)})
meta['imports']=imports
(out/'pe-metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
with (out/'imports.tsv').open('w') as f:
    f.write('dll\tname\tordinal\taddress\n')
    for imp in imports:f.write('\t'.join(str(imp[k] or '') for k in ['dll','name','ordinal','address'])+'\n')
raw=src.read_bytes()
for label, pattern, encoding in [('ascii',rb'[\x20-\x7e]{5,}','ascii'),('utf16le',rb'(?:[\x20-\x7e]\x00){5,}','utf-16-le')]:
    with (out/f'strings-{label}.tsv').open('w',encoding='utf-8') as f:
        f.write('file_offset\tstring\n')
        for match in re.finditer(pattern,raw):f.write(f'{match.start():08x}\t{match.group().decode(encoding)}\n')
resources=out/'resources'; resources.mkdir(exist_ok=True)
manifest=[]
def walk(directory,parts=()):
    for e in directory.entries:
        label=str(e.name) if e.name is not None else str(e.id)
        path=parts+(label,)
        if hasattr(e,'directory'):walk(e.directory,path)
        elif hasattr(e,'data'):
            d=e.data.struct
            name='_'.join(re.sub(r'[^\w.-]','_',p) for p in path)+'.bin'
            (resources/name).write_bytes(pe.get_data(d.OffsetToData,d.Size))
            manifest.append({'path':list(path),'file':name,'rva':hex(d.OffsetToData),'size':d.Size})
if hasattr(pe,'DIRECTORY_ENTRY_RESOURCE'):walk(pe.DIRECTORY_ENTRY_RESOURCE)
(resources/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
debug=[]
for d in getattr(pe,'DIRECTORY_ENTRY_DEBUG',[]):
    entry=d.struct
    data=raw[entry.PointerToRawData:entry.PointerToRawData+entry.SizeOfData]
    debug.append({'type':entry.Type,'raw_hex':data.hex(),'pdb_path':data[24:].rstrip(b'\0').decode(errors='replace') if data.startswith(b'RSDS') else None})
(out/'debug-directory.json').write_text(json.dumps(debug,indent=2),encoding='utf-8')
print(json.dumps({'imports':len(imports),'resource_entries':len(manifest),'debug':debug,'clr_header_present':meta['clr_header_present']},indent=2))
