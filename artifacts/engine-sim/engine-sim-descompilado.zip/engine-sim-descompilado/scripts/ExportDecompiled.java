// Export analyzed functions as C-like pseudocode and navigation tables.
// @category Export
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.data.StringDataInstance;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ExportDecompiled extends GhidraScript {
    private String clean(Object o) { return String.valueOf(o).replace("\t", " ").replace("\r", "\\r").replace("\n", "\\n"); }
    private PrintWriter writer(File dir, String name) throws Exception {
        return new PrintWriter(new OutputStreamWriter(new FileOutputStream(new File(dir,name)), StandardCharsets.UTF_8));
    }
    public void run() throws Exception {
        File out = new File(getScriptArgs()[0]); out.mkdirs();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true); decomp.toggleSyntaxTree(false);
        if (!decomp.openProgram(currentProgram)) throw new IOException("Cannot initialize decompiler");
        int count=0, ok=0, failed=0, external=0;
        try (PrintWriter c=writer(out,"decompiled.c"); PrintWriter index=writer(out,"functions.tsv"); PrintWriter calls=writer(out,"calls.tsv")) {
            c.println("/* Ghidra 11.4.2 output from engine-sim-app.exe. */");
            c.println("/* Pseudocode for analysis; not original source and not a compilable project. */\n");
            index.println("address\tname\tsize_bytes\tstatus\tdecompiled_c_line\tdetail");
            calls.println("caller_address\tcaller\tcallee_address\tcallee");
            int line=4;
            FunctionIterator it=currentProgram.getFunctionManager().getFunctions(true);
            while(it.hasNext() && !monitor.isCancelled()) {
                Function f=it.next(); if(f.isExternal()) { external++; continue; }
                count++;
                DecompileResults r=decomp.decompileFunction(f,30,monitor);
                String code;
                String status;
                if(r.decompileCompleted() && r.getDecompiledFunction()!=null) {
                    code=r.getDecompiledFunction().getC(); ok++; status="OK";
                } else { code="/* Could not decompile: "+clean(r.getErrorMessage())+" */\n"; failed++; status="FAILED"; }
                String banner="/* ===== "+f.getEntryPoint()+" : "+f.getName(true)+" ===== */";
                c.println(banner); c.print(code); c.println();
                index.println(f.getEntryPoint()+"\t"+clean(f.getName(true))+"\t"+f.getBody().getNumAddresses()+"\t"+status+"\t"+line+"\t"+clean(r.getErrorMessage()));
                line+=1+(int)code.chars().filter(ch->ch=='\n').count()+1;
                for(Function target:f.getCalledFunctions(monitor)) calls.println(f.getEntryPoint()+"\t"+clean(f.getName(true))+"\t"+target.getEntryPoint()+"\t"+clean(target.getName(true)));
                if(count%200==0) { println("EXPORT progress: "+count+", ok="+ok+", failed="+failed); c.flush(); index.flush(); }
            }
        } finally { decomp.dispose(); }
        try(PrintWriter strings=writer(out,"strings_xrefs.tsv")) {
            strings.println("address\tstring\treference_address\tcontaining_function");
            DataIterator it=currentProgram.getListing().getDefinedData(true);
            while(it.hasNext()) {
                Data d=it.next(); if(!StringDataInstance.isString(d)) continue;
                String value=StringDataInstance.getStringDataInstance(d).getStringValue();
                ReferenceIterator refs=currentProgram.getReferenceManager().getReferencesTo(d.getAddress());
                boolean found=false;
                while(refs.hasNext()) {
                    found=true; Reference r=refs.next(); Function f=currentProgram.getFunctionManager().getFunctionContaining(r.getFromAddress());
                    strings.println(d.getAddress()+"\t"+clean(value)+"\t"+r.getFromAddress()+"\t"+(f==null?"":clean(f.getName(true))));
                }
                if(!found) strings.println(d.getAddress()+"\t"+clean(value)+"\t\t");
            }
        }
        try(PrintWriter s=writer(out,"decompilation-summary.txt")) {
            s.println("Program: "+currentProgram.getName());
            s.println("Language: "+currentProgram.getLanguageID());
            s.println("Compiler spec: "+currentProgram.getCompilerSpec().getCompilerSpecID());
            s.println("Functions attempted: "+count); s.println("Decompiled: "+ok); s.println("Failed: "+failed); s.println("External skipped: "+external);
        }
        println("EXPORT DONE: attempted="+count+", decompiled="+ok+", failed="+failed);
    }
}
