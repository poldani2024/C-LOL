# Referencias útiles

Las descripciones se basan en cadenas referenciadas; no son nombres originales recuperados. Las líneas corresponden a `decompiled.c`.

| Cadena | Función que la referencia | Línea |
|---|---|---|
| Engine Sim \| AngeTheGreat \| | `FUN_14000a3c0` | 7085 |
| Error: No engine found. | `FUN_14000b6e0` | 7885 |
| Engine Simulator Scripts (.mr) | `FUN_14001cbb0` | 18046 |
| Using a crankshaft that does not belong to the correct engine. | `FUN_14004ee90` | 52609 |
| Wankel engine has no rotors. | `FUN_14004b6e0` | 50180 |
