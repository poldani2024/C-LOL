# Descompilación de engine-sim-app.exe

Se realizó análisis estático con Ghidra 11.4.2. El ejecutable original no se ejecutó.

## Resultado

- Archivo: Windows PE32+ x86-64, 1,597,440 bytes.
- SHA-256 del original: `a24170167a494e7b43069f6b9323a37208e8eaa97a6b976793a16bdae9e1a55e`.
- Código nativo con ABI Windows y evidencia de C++/MSVC; no contiene encabezado CLR de .NET.
- Linker PE: 14.29. La fecha declarada por el encabezado es 2023-04-30 UTC; no autentica la fecha real.
- 3,239 funciones detectadas y exportadas a pseudocódigo; 0 fallos del proceso de descompilación.
- 334 importaciones de 26 DLL, 12 recursos PE y 278 nombres RTTI simples extraídos.
- Las cadenas identifican Engine Simulator / AngeTheGreat e incluyen componentes de motores de pistones y Wankel. No se verificó la equivalencia con una versión concreta de código fuente público.

## Qué abrir

- `output/decompiled.c`: pseudocódigo C generado, 140.093 líneas.
- `output/functions.tsv`: dirección, nombre, tamaño, estado y línea de cada función en el pseudocódigo.
- `output/puntos-de-entrada.md`: referencias útiles para empezar a navegar.
- `output/calls.tsv`: relaciones de llamadas detectadas estáticamente.
- `output/strings_xrefs.tsv`: cadenas reconocidas por Ghidra y funciones que las referencian.
- `output/disassembly.asm`: desensamblado x86-64 en sintaxis Intel.
- `output/imports.tsv`, `output/pe-metadata.json`, `output/pe-headers.txt`: importaciones y metadatos.
- `output/strings-ascii.tsv`, `output/strings-utf16le.tsv`: cadenas recuperadas por búsqueda binaria con desplazamientos de archivo.
- `output/rtti-class-names.txt`: nombres conservados en RTTI (incluye componentes y bibliotecas).
- `output/resources/application.ico`: icono reconstruido con sus diez imágenes.
- `output/resources/application.manifest`: manifiesto Windows.
- `output/resources/manifest.json`: índice de los doce recursos; los `.bin` conservan sus bytes.
- `project/EngineSim.gpr` y `project/EngineSim.rep/`: proyecto analizado de Ghidra. Conservar ambos juntos; abrir el `.gpr` en Ghidra 11.4.2 o posterior y luego abrir `engine-sim-app.exe` desde el proyecto.
- `scripts/ExportDecompiled.java`: script utilizado para exportar pseudocódigo e índices.

Los `.tsv` se pueden abrir en un editor o una hoja de cálculo con separador tabulador. Las direcciones de Ghidra se basan en la imagen cargada en `0x140000000`; los offsets de los archivos de cadenas binarias son posiciones en el archivo y son distintos de las direcciones virtuales.

## Límites de recuperación

El pseudocódigo NO es el código fuente original ni un proyecto listo para compilar. Los nombres `FUN_...`, `DAT_...`, tipos `undefined...` y muchas firmas son inferidos. No se recuperan comentarios, macros, configuración de compilación ni todos los nombres de variables. No se encontró información CodeView/PDB en el ejecutable.

El archivo de pseudocódigo conserva 1.369 advertencias de Ghidra: incluyen funciones sin retorno, saltos indirectos y tablas de salto o tipos no resueltos. La exportación exitosa no garantiza que cada función sea semánticamente exacta ni que se haya detectado todo el código. Las llamadas virtuales y otros destinos dinámicos requieren revisión manual.

Las DLL externas (por ejemplo SDL2, SDL2_image, runtime de C++ y APIs gráficas de Windows) no fueron proporcionadas: se identifican sus importaciones, pero no se descompila su implementación. Los assets, sonidos y scripts `.mr` externos tampoco se reconstruyen a partir de sus nombres de ruta.

Durante el primer análisis hubo una advertencia al cargar el script auxiliar WindowsResourceReference. Se ejecutó correctamente en una segunda pasada; los recursos también se extrajeron directamente del PE. Se conservan ambos registros para trazabilidad. No hubo timeout de análisis.

## Repetir la exportación

Con Ghidra 11.4.2 instalado y un JDK compatible, desde la raíz de este paquete:

```bash
/RUTA/GHIDRA/support/analyzeHeadless ./project EngineSim \
  -process engine-sim-app.exe -noanalysis \
  -scriptPath ./scripts -postScript ExportDecompiled.java ./output
```

La distribución oficial de Ghidra utilizada fue `ghidra_11.4.2_PUBLIC_20250826.zip`; SHA-256 verificado contra la página oficial: `795a02076af16257bd6f3f4736c4fc152ce9ff1f95df35cd47e2adc086e037a6`.

Se comprobaron las 3.239 entradas del índice contra las líneas reales del pseudocódigo. Los registros y el resumen exacto están en `output/ghidra-*.log` y `output/decompilation-summary.txt`. El ZIP se verificó con CRC después de generarlo.
